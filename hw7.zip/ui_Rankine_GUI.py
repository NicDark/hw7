# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Rankine_GUIVqHcJD.ui'
##
## Created by: Qt User Interface Compiler version 5.14.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import (QCoreApplication, QMetaObject, QObject, QPoint,
    QRect, QSize, QUrl, Qt)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont,
    QFontDatabase, QIcon, QLinearGradient, QPalette, QPainter, QPixmap,
    QRadialGradient)
from PySide2.QtWidgets import *


class Ui_Form(object):
    def setupUi(self, Form):
        if Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(919, 569)
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.gb_Input = QGroupBox(Form)
        self.gb_Input.setObjectName(u"gb_Input")
        font = QFont()
        font.setPointSize(12)
        self.gb_Input.setFont(font)
        self.gridLayout = QGridLayout(self.gb_Input)
        self.gridLayout.setObjectName(u"gridLayout")
        self.lbl_PHigh = QLabel(self.gb_Input)
        self.lbl_PHigh.setObjectName(u"lbl_PHigh")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lbl_PHigh.sizePolicy().hasHeightForWidth())
        self.lbl_PHigh.setSizePolicy(sizePolicy)
        self.lbl_PHigh.setFont(font)

        self.gridLayout.addWidget(self.lbl_PHigh, 0, 0, 1, 1, Qt.AlignRight)

        self.btn_Calculate = QPushButton(self.gb_Input)
        self.btn_Calculate.setObjectName(u"btn_Calculate")
        self.btn_Calculate.setFont(font)

        self.gridLayout.addWidget(self.btn_Calculate, 0, 2, 2, 2)

        self.lbl_PLow = QLabel(self.gb_Input)
        self.lbl_PLow.setObjectName(u"lbl_PLow")
        sizePolicy.setHeightForWidth(self.lbl_PLow.sizePolicy().hasHeightForWidth())
        self.lbl_PLow.setSizePolicy(sizePolicy)
        self.lbl_PLow.setFont(font)

        self.gridLayout.addWidget(self.lbl_PLow, 1, 0, 1, 1, Qt.AlignRight)

        self.le_PLow = QLineEdit(self.gb_Input)
        self.le_PLow.setObjectName(u"le_PLow")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.le_PLow.sizePolicy().hasHeightForWidth())
        self.le_PLow.setSizePolicy(sizePolicy1)
        self.le_PLow.setFont(font)
        self.le_PLow.setClearButtonEnabled(True)

        self.gridLayout.addWidget(self.le_PLow, 1, 1, 1, 1)

        self.le_PHigh = QLineEdit(self.gb_Input)
        self.le_PHigh.setObjectName(u"le_PHigh")
        sizePolicy1.setHeightForWidth(self.le_PHigh.sizePolicy().hasHeightForWidth())
        self.le_PHigh.setSizePolicy(sizePolicy1)
        self.le_PHigh.setFont(font)
        self.le_PHigh.setClearButtonEnabled(True)

        self.gridLayout.addWidget(self.le_PHigh, 0, 1, 1, 1)

        self.le_TurbineInletCondition = QLineEdit(self.gb_Input)
        self.le_TurbineInletCondition.setObjectName(u"le_TurbineInletCondition")
        sizePolicy1.setHeightForWidth(self.le_TurbineInletCondition.sizePolicy().hasHeightForWidth())
        self.le_TurbineInletCondition.setSizePolicy(sizePolicy1)
        self.le_TurbineInletCondition.setFont(font)
        self.le_TurbineInletCondition.setClearButtonEnabled(True)

        self.gridLayout.addWidget(self.le_TurbineInletCondition, 2, 1, 1, 1)

        self.lbl_TurbineInletCondition = QLabel(self.gb_Input)
        self.lbl_TurbineInletCondition.setObjectName(u"lbl_TurbineInletCondition")
        sizePolicy.setHeightForWidth(self.lbl_TurbineInletCondition.sizePolicy().hasHeightForWidth())
        self.lbl_TurbineInletCondition.setSizePolicy(sizePolicy)
        self.lbl_TurbineInletCondition.setFont(font)

        self.gridLayout.addWidget(self.lbl_TurbineInletCondition, 2, 0, 1, 1, Qt.AlignRight)

        self.rdo_Quality = QRadioButton(self.gb_Input)
        self.rdo_Quality.setObjectName(u"rdo_Quality")
        self.rdo_Quality.setFont(font)
        self.rdo_Quality.setChecked(True)

        self.gridLayout.addWidget(self.rdo_Quality, 2, 2, 1, 1)

        self.rdo_THigh = QRadioButton(self.gb_Input)
        self.rdo_THigh.setObjectName(u"rdo_THigh")
        self.rdo_THigh.setFont(font)

        self.gridLayout.addWidget(self.rdo_THigh, 2, 3, 1, 1)

        self.label = QLabel(self.gb_Input)
        self.label.setObjectName(u"label")
        self.label.setFont(font)
        self.label.setTextFormat(Qt.PlainText)

        self.gridLayout.addWidget(self.label, 3, 0, 1, 1, Qt.AlignRight)

        self.le_TurbineEff = QLineEdit(self.gb_Input)
        self.le_TurbineEff.setObjectName(u"le_TurbineEff")
        self.le_TurbineEff.setFont(font)
        self.le_TurbineEff.setClearButtonEnabled(True)

        self.gridLayout.addWidget(self.le_TurbineEff, 3, 1, 1, 1)

        self.lbl_SatPropHigh = QLabel(self.gb_Input)
        self.lbl_SatPropHigh.setObjectName(u"lbl_SatPropHigh")
        self.lbl_SatPropHigh.setFont(font)

        self.gridLayout.addWidget(self.lbl_SatPropHigh, 4, 1, 1, 1)

        self.lbl_SatPropLow = QLabel(self.gb_Input)
        self.lbl_SatPropLow.setObjectName(u"lbl_SatPropLow")
        self.lbl_SatPropLow.setFont(font)

        self.gridLayout.addWidget(self.lbl_SatPropLow, 4, 2, 1, 2)


        self.verticalLayout.addWidget(self.gb_Input)

        self.gb_Output = QGroupBox(Form)
        self.gb_Output.setObjectName(u"gb_Output")
        sizePolicy2 = QSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.MinimumExpanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.gb_Output.sizePolicy().hasHeightForWidth())
        self.gb_Output.setSizePolicy(sizePolicy2)
        self.gb_Output.setFont(font)
        self.gridLayout_2 = QGridLayout(self.gb_Output)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.label_4 = QLabel(self.gb_Output)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font)

        self.gridLayout_2.addWidget(self.label_4, 0, 2, 1, 1)

        self.label_5 = QLabel(self.gb_Output)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font)

        self.gridLayout_2.addWidget(self.label_5, 1, 0, 1, 1)

        self.label_8 = QLabel(self.gb_Output)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font)

        self.gridLayout_2.addWidget(self.label_8, 2, 2, 1, 1)

        self.le_H2 = QLineEdit(self.gb_Output)
        self.le_H2.setObjectName(u"le_H2")
        self.le_H2.setEnabled(False)
        self.le_H2.setFont(font)

        self.gridLayout_2.addWidget(self.le_H2, 1, 1, 1, 1)

        self.label_7 = QLabel(self.gb_Output)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font)

        self.gridLayout_2.addWidget(self.label_7, 3, 0, 1, 1)

        self.le_H4 = QLineEdit(self.gb_Output)
        self.le_H4.setObjectName(u"le_H4")
        self.le_H4.setEnabled(False)
        self.le_H4.setFont(font)

        self.gridLayout_2.addWidget(self.le_H4, 3, 1, 1, 1)

        self.le_H3 = QLineEdit(self.gb_Output)
        self.le_H3.setObjectName(u"le_H3")
        self.le_H3.setEnabled(False)
        self.le_H3.setFont(font)

        self.gridLayout_2.addWidget(self.le_H3, 2, 1, 1, 1)

        self.label_9 = QLabel(self.gb_Output)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font)

        self.gridLayout_2.addWidget(self.label_9, 2, 0, 1, 1)

        self.le_H1 = QLineEdit(self.gb_Output)
        self.le_H1.setObjectName(u"le_H1")
        self.le_H1.setEnabled(False)
        self.le_H1.setFont(font)

        self.gridLayout_2.addWidget(self.le_H1, 0, 1, 1, 1)

        self.le_TurbineWork = QLineEdit(self.gb_Output)
        self.le_TurbineWork.setObjectName(u"le_TurbineWork")
        self.le_TurbineWork.setEnabled(False)
        self.le_TurbineWork.setFont(font)

        self.gridLayout_2.addWidget(self.le_TurbineWork, 0, 4, 1, 1)

        self.le_HeatAdded = QLineEdit(self.gb_Output)
        self.le_HeatAdded.setObjectName(u"le_HeatAdded")
        self.le_HeatAdded.setEnabled(False)
        self.le_HeatAdded.setFont(font)

        self.gridLayout_2.addWidget(self.le_HeatAdded, 2, 4, 1, 1)

        self.label_15 = QLabel(self.gb_Output)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setFont(font)
        self.label_15.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_2.addWidget(self.label_15, 1, 3, 1, 1)

        self.label_11 = QLabel(self.gb_Output)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setFont(font)
        self.label_11.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_2.addWidget(self.label_11, 2, 3, 1, 1)

        self.label_16 = QLabel(self.gb_Output)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setFont(font)

        self.gridLayout_2.addWidget(self.label_16, 2, 5, 1, 1)

        self.label_17 = QLabel(self.gb_Output)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setFont(font)

        self.gridLayout_2.addWidget(self.label_17, 0, 5, 1, 1)

        self.label_14 = QLabel(self.gb_Output)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setFont(font)
        self.label_14.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_2.addWidget(self.label_14, 0, 3, 1, 1)

        self.le_PumpWork = QLineEdit(self.gb_Output)
        self.le_PumpWork.setObjectName(u"le_PumpWork")
        self.le_PumpWork.setEnabled(False)
        self.le_PumpWork.setFont(font)

        self.gridLayout_2.addWidget(self.le_PumpWork, 1, 4, 1, 1)

        self.label_10 = QLabel(self.gb_Output)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font)
        self.label_10.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_2.addWidget(self.label_10, 3, 3, 1, 1, Qt.AlignRight)

        self.le_Efficiency = QLineEdit(self.gb_Output)
        self.le_Efficiency.setObjectName(u"le_Efficiency")
        self.le_Efficiency.setEnabled(False)
        self.le_Efficiency.setFont(font)

        self.gridLayout_2.addWidget(self.le_Efficiency, 3, 4, 1, 1)

        self.label_3 = QLabel(self.gb_Output)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font)

        self.gridLayout_2.addWidget(self.label_3, 1, 2, 1, 1)

        self.label_12 = QLabel(self.gb_Output)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font)

        self.gridLayout_2.addWidget(self.label_12, 3, 5, 1, 1)

        self.label_6 = QLabel(self.gb_Output)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setFont(font)

        self.gridLayout_2.addWidget(self.label_6, 3, 2, 1, 1)

        self.label_13 = QLabel(self.gb_Output)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font)

        self.gridLayout_2.addWidget(self.label_13, 1, 5, 1, 1)

        self.label_2 = QLabel(self.gb_Output)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setFont(font)
        self.label_2.setFocusPolicy(Qt.WheelFocus)

        self.gridLayout_2.addWidget(self.label_2, 0, 0, 1, 1)


        self.verticalLayout.addWidget(self.gb_Output)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.gb_Input.setTitle(QCoreApplication.translate("Form", u"Input", None))
        self.lbl_PHigh.setText(QCoreApplication.translate("Form", u"P High (bar)", None))
        self.btn_Calculate.setText(QCoreApplication.translate("Form", u"Calculate", None))
        self.lbl_PLow.setText(QCoreApplication.translate("Form", u"P Low (bar)", None))
        self.le_PLow.setText(QCoreApplication.translate("Form", u"0.08", None))
        self.le_PLow.setPlaceholderText(QCoreApplication.translate("Form", u"enter a value for the low pressure isobar", None))
        self.le_PHigh.setText(QCoreApplication.translate("Form", u"80", None))
        self.le_PHigh.setPlaceholderText(QCoreApplication.translate("Form", u"enter a value for the high pressure isobar", None))
        self.le_TurbineInletCondition.setText(QCoreApplication.translate("Form", u"1.0", None))
        self.lbl_TurbineInletCondition.setText(QCoreApplication.translate("Form", u"Turbine Inlet: x =", None))
        self.rdo_Quality.setText(QCoreApplication.translate("Form", u"Quality", None))
        self.rdo_THigh.setText(QCoreApplication.translate("Form", u"T High", None))
        self.label.setText(QCoreApplication.translate("Form", u"Turbine Eff.", None))
        self.le_TurbineEff.setText(QCoreApplication.translate("Form", u"1.0", None))
        self.le_TurbineEff.setPlaceholderText(QCoreApplication.translate("Form", u"turbine isentropic efficiency 0.0<eta<=1.0", None))
        self.lbl_SatPropHigh.setText(QCoreApplication.translate("Form", u"Saturated Properties", None))
        self.lbl_SatPropLow.setText(QCoreApplication.translate("Form", u"Saturated Properties", None))
        self.gb_Output.setTitle(QCoreApplication.translate("Form", u"Output", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"h2", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"h4", None))
        self.label_9.setText(QCoreApplication.translate("Form", u"h3", None))
        self.label_15.setText(QCoreApplication.translate("Form", u"Pump Work", None))
        self.label_11.setText(QCoreApplication.translate("Form", u"Heat Added", None))
        self.label_16.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_17.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_14.setText(QCoreApplication.translate("Form", u"Turbine Work", None))
        self.label_10.setText(QCoreApplication.translate("Form", u"Thermal Efficiency", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_12.setText(QCoreApplication.translate("Form", u"%", None))
        self.label_6.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_13.setText(QCoreApplication.translate("Form", u"kJ/kg", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"h1", None))
    # retranslateUi

